/**
 * Created by hisp on 1/12/15.
 */

bidReportsApp
.controller('homeController', function( $rootScope,
                                         $scope){


    });
